#
# hw3pr4.py - extra credit problem "Sounds Good!"
#
# Name:
#
#

import csaudio
from csaudio import *


# a function to make sure everything is working
def test():
    """ a test function that plays swfaith.wav
        You'll need swfailt.wav in this folder.
    """
    play( 'swfaith.wav' )

    
